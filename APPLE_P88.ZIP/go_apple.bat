as\bin\asl.exe APPLE.ASM -L
as\bin\p2bin.exe APPLE.p