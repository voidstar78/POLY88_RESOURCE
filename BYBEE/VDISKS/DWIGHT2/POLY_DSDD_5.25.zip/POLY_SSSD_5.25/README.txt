
In each directory, you'll find the image of one 5.25 single density
hard sectored disk. Some of the disk are truncated because of errors
reading inner sectors but most of the extracted data is complete.
If the extracted data was a .TX, some BS, PS or PV, the 0Dh values
have been expanded on extracting to 0Dh 0Ah. I'm not sure if
this would be an issue converting these back to Poly disks.
If so, remove the 0Ah as it is written back to the disk or extract
originals from the images.
The images are just the data portions of the disk and not the
headers or check sums.
The directory name is chosen to assist in figuring what that disk
contained. For more analysis, look at the file *.txt in the
directory. It includes listings of the image directory plus
any size, load and run information needed.
I used the file readdisk.f in this directory to read the disk.
It is written in Forth. Using Win34Forth that runs on windows.
Dwight
