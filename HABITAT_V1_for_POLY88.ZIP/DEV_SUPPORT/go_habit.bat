as\bin\asl.exe HABIT.ASM -L
as\bin\p2bin.exe HABIT.p